<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>MVC</title>
    </head>
    <body>
<?php
if (isset($_SESSION['flash']) && isset($_SESSION['flash']['errs'])) {
    if (is_string($_SESSION['flash']['errs'])) {
        echo '<div class="error">'. $_SESSION['flash']['errs'] . '</div>';
    } elseif(is_array($_SESSION['flash']['errs'])) {
        foreach ($_SESSION['flash']['errs'] as $class => $cols) {
            echo '<div class="error">';
            if (is_string($cols)) {
                echo $cols;
            } elseif(is_array($cols)) {
                foreach($cols as $col => $errs) {
                    echo ucfirst($col) . '<ul>';
                    foreach ($errs as $err) {
                        echo '<li>' . $err . '</li>';
                    }
                    echo '</ul>';
                }
            }
            echo '</div>';
        }
    }
}
if (isset($_SESSION['flash']) && isset($_SESSION['flash']['info'])) {
    if (is_string($_SESSION['flash']['info'])) {
        echo '<div class="info">'. $_SESSION['flash']['info'] . '</div>';
    }
}
?>
